<?php
    $page ="Login";
    include "../includes/connect.php";
    include "../includes/header.php";
    include "../includes/navigation.php";
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="login">
                <div class="form">
    <h1>Welcome</h1>
    <p>We're happy to see you return! Please login to continue.</p>
    
        <?php
            //user messages
            if(isset($_SESSION['error'])) //if session error is set
                {
                    echo '<div class="error">';
                    echo '<p>' . $_SESSION['error'] . '</p>'; //display error messgae
                    echo '</div>';
                    unset($_SESSION['error']); //unset session error
                }
        ?>
    
    <form action="loginprocessing.php" method="post">
        <input type="text" name="username" id="username" placeholder="Enter your username" required/> <br />
        <input type="password" name="password" id="password" placeholder="Enter your password" requried/> <br />
        <input type="hidden" value="<?php echo $_GET['reviewID']; ?>" name="reviewID" />
        <p><input type="submit" name="Login" value="Login" class="btn" /></p>
    </form>
    <p>Don't have an account yet? Please <a href="registration.php">sign up</a> today.</p>
                    </div>
                    </div>
                </div>
</section> <!-- end content -->

        </div>
</div>

<?php
    include "../includes/footer.php";
?>