<?php
    $page = "Search Results";
    include "../includes/connect.php";
    include '../includes/header.php';
    include '../includes/navigation.php';
?>
<div id="main">

        <section>
            <div class="container">
                <?php
                    include '../includes/searchbar.php';
?>
 <h1>Search Results</h1>
    <?php
        $term = mysqli_real_escape_string($con, $_GET['search-terms']); //prevent SQL injection
 
        $sql = "SELECT review.*, admin.adminID, admin.firstName, genre.*, platform.*
                FROM review 
                INNER JOIN admin USING(adminID) 
                INNER JOIN genre USING(genreID)
                INNER JOIN platform USING(platformID)
                WHERE title LIKE '%$term%' OR content LIKE '%$term%' OR genreName LIKE '%$term%' OR platformName LIKE '%$term%' OR firstName LIKE '%$term%' 
                ORDER BY date DESC"; // use LIKE to find values that match the term entered and order by date from the most recent review
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
 
        $numrow = mysqli_num_rows($result); //count the number of rows returned
        if(empty($_GET['search-terms'])) //display if no search term entered
            {
                echo "<p><em>You did not enter a search term</em></p>";
            }
        else if($numrow == 0) //display if no matches to search
            {
                echo "<p><em>Sorry, no results match your search for <strong>" . $term . "</strong></em></p>";
            }
        else
            {
                echo "<p><em>Your search for <strong>" . $term . "</strong> has retrieved " . $numrow . " results</em></p>"; //display the search results
                while ($row = mysqli_fetch_array($result)) //loop through results for each match
                    {
                       echo preg_replace("/($term)/i","<span class='keyword'>$0</span>", "<h2 class='spaceTop spaceBottom'><a href='blogpost.php?reviewID=" .$row['reviewID'] . "'>" . $row['title'] . "</a></h2>");
                        echo "<p class='details'><em>posted on " . date("F jS Y, g:ia",strtotime($row['date'])) . " by " . preg_replace("/($term)/i","<span class='keyword'>$0</span>", $row['firstName']) . " in " . preg_replace("/($term)/i","<span class='keyword'>$0</span>", $row['genreName']) ."</em></p>"; //display the date, author and category
                        echo preg_replace("/($term)/i","<span class='keyword'>$0</span>",
                        "<p>" . (substr(($row['content']),0,100)) . "..." . "</p><br />"); //limit displayed characters to 100
                    }
            }          
 ?>
    
<?php
    include '../includes/sidebar.php';
?>
 
 </div>
</section> <!-- end content -->

        </div>
</div>
 
<?php
    include '../includes/footer.php';
?>
