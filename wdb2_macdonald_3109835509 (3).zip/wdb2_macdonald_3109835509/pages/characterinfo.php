<?php
    include '../includes/connect.php';
    
    //display HTML title tag for each review entry
    $sql = "SELECT * FROM chara WHERE charID =" . $_GET['charID']; //select the post using the reviewID
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    while($row = mysqli_fetch_array($result))
    {
        $page = $row['charaName'];   
    }
    include '../includes/header.php';
    include '../includes/navigation.php';
?>
<div id="main">

            <section>
                <div class="container">
                    <?php
                     $sql = "SELECT *
                    FROM chara
                    WHERE chara.charID =" . $_GET['charID']; //retrieve the comment for the reviewID

            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
 
          //  $numrows = mysqli_num_rows($result);

           
            if(mysqli_num_rows($result) > 0)
                {
                    while ($row = mysqli_fetch_array($result))
                        {
                           
                            echo "<img src='../images/" . $row['charImage'] . "'" . ' class="charaImage" alt="contact photo"' . "/>";
                            echo "<h2>" . $row['charName'] . "</h2>";
                            echo $row['charQuote'];
                            echo $row['attributeID'];
                            echo $row['charDescription'];
                            echo "<br />";
                            echo "<hr>";
                            echo "<a href='blogpost.php?reviewID=" . $row['reviewID'] . "'>" . "Go back" . "</a>";
                            
                            
                        }
                }
                    ?>
                </div>
            </section>
</div>