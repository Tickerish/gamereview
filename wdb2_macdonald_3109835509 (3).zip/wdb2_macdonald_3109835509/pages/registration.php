<?php
    $page = "Login";
    include "../includes/connect.php";
    include "../includes/header.php"; //session_start(); included in header.php
    include "../includes/navigation.php";
?>
<div id="main">

        <section>
            <div class="container">
                <div class="registration">
                    <div class="form">
    <h1>Become a gamer.</h1>
    <p>Complete the details below to sign up for new account.</p>
    <p>Passwords must have a minimum of 8 characters.</p>
    
    <?php
        //user messages
        if(isset($_SESSION['error'])) //if session error is set
            {
                echo '<div class="error"';
                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                echo '</div>';
                unset($_SESSION['error']); //unset session error
            }
    ?>
    
    <form action="registrationprocessing.php" method="post" enctype="multipart/form-data">
        <label>*</label>
            <input type="text" name="username" placeholder="Please enter username" required />
        <br />
        <label>*</label>
            <input type="password" name="password" placeholder="please enter password" required pattern=".{8,}" title="password must be 8 characters or more" />
        <br />
        <label>*</label>
            <input type="text" name="firstName" placeholder="please enter firstname" required />
        <br />
        <label>*</label>
            <input type="text" name="lastName" placeholder="please enter last name" required />
        <br />
        <label></label>
            <input type="text" placeholder="please enter street" name="street" />
        <br />
        <label></label>
            <input type="text" placeholder="please enter suburb" name="suburb" />
        <br />
        <label></label>
            <?php
                //generate drop-down list for state using enum data type and values from database
                $tableName='member';
                $colState='state';

                function getEnumState($tableName, $colState)
                    {
                        global $con; //enable database connection function
                        $sql = "SHOW COLUMNS FROM $tableName 
                                WHERE field='$colState'"; //retrieve enum column
                        $result = mysqli_query($con, $sql) or die(mysqli_error($con));
                        $row = mysqli_fetch_array($result); //store the results in a variable named '$row'
                        $type = preg_replace('/(^enum\()/i', '', $row['Type']); //regular expression to replace the enum syntax with blank space
                        $enumValues = substr($type, 0, -1); //return the enum string
                        $enumExplode = explode(',', $enumValues); //split the enum string into individual values
                        return $enumExplode; //return all enum individual values
                    }
                    $enumValues = getEnumState('member', 'state');
                    echo '<select name="state">';
                    echo "<option value=''>Please select</option>";
                    foreach($enumValues as $value)
                        {
                            echo '<option value="' . $removeQuotes = str_replace("'", "", $value) . '">' . $removeQuotes = str_replace("'", "", $value) . '</option>'; //remove the quotes from the enum values
                        }
                    echo '</select><br />'
            ?>
        <p>&nbsp;</p>
        <label>*</label>
            <input type="text" name="postcode" placeholder="please enter postcode" required />
        <br />
        <label>*</label>
            <input type="text" name="country" placeholder="please enter country" required />
        <br />
        <label></label>
            <input type="text" placeholder="please enter phone number" name="phone" />
        <br />
        <label></label>
            <input type="text" placeholder="please enter mobile number" name="mobile" />
        <br />
        <label>*</label>
            <input type="email" placeholder="please enter email" name="email" required />
        <br />
        <label>*</label>
            <?php
                //generate drop-down list for gender using enum data type and values from database
                        $tableName='member';
                        $colGender='gender';

                        function getEnumGender($tableName, $colGender)
                            {
                                global $con; //enable database connection in the function
                                $sql = "SHOW COLUMNS FROM $tableName
                                        WHERE field='$colGender'"; //retrieve enum column
                                $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                                $row = mysqli_fetch_array($result); //store the results in a variable named $row
                                $type = preg_replace('/(^enum\()/i', '', $row['Type']); //regular expression to replace the enum sytax with blank space
                                $enumValues = substr($type, 0, -1); //return the enum string
                                $enumExplode = explode(',', $enumValues); //split the enum string into individual values
                                return $enumExplode; //return all the enum individual values
                            }
                            $enumValues = getEnumGender('member', 'gender');
                            echo '<select name="gender">';
                            echo "<option value=''>Please Select</option>";

                            foreach($enumValues as $value)
                                {
                                    echo '<option value"' . $removeQuotes = str_replace("'","", $value) . '">' . $removeQuotes = str_replace("'", "", $value) . '</option>';
                                }
                            echo '</select>';
            ?>
        <br />
        <p>Subscribe to weekly email newsletter?</p>
        <label>Yes</label>
            <input type="radio" name="newsletter" value="Y" checked> 
        <br />
        <label>No</label>
            <input type="radio" name="newsletter" value="N">
        <br />
        <label>Image</label>
            <input type="file" id="image" name="image" />
        <p>Accepted files are JPG, GIF, or PNG. Maximum size is 500kb.</p>
        <p><input type="submit" name="registration" value="Create New Account" class="btn" /></p>
    </form>
                    </div>
                </div>
            </div>
        </section> <!-- end content -->

    </div>
</div>

<?php
    include '../includes/footer.php';
?>