<?php
    $page = "Home";
    include '../includes/connect.php';
    include '../includes/header.php';
    include '../includes/navigation.php';
?>
<div id="main">
        <section>
            <div class="container">
                <?php
                     
                    //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                        elseif(isset($_SESSION['success'])) //if session success is set
                            {
                                echo '<div class="success">';
                                echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                                echo '</div>';
                                unset($_SESSION['success']); //unset success message
                            }
                   
                    include '../includes/searchbar.php';
?>
    <?php
        $sql = "SELECT admin.adminID, admin.firstName, review.*, genre.*, platform.*, COUNT(comment.reviewID) AS commentcount
                FROM review
                INNER JOIN admin ON review.adminID = admin.adminID
                INNER JOIN genre ON genre.genreID = genre.genreID
                INNER JOIN platform ON platform.platformID = platform.platformID
                LEFT JOIN comment ON review.reviewID = comment.reviewID
                GROUP BY review.reviewID, comment.reviewID
                ORDER BY date DESC LIMIT 0,3"; //display the last 3 reviews and count the number of comments for each review
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
        while ($row = mysqli_fetch_array($result))
            {
                if((is_null($row['image'])) || (empty($row['image']))) //if the image field is NULL or empty
                {
                    echo "<img src='../images/default.png' class='banner' alt='GameOn Banner' /></p>"; //display the default image   
                }
                else
                {
                    echo "<img src='../images/" . ($row['image']) . "'" . ' class="banner" alt="GameOn"' . "/>"; //else display the review image
                }
                echo "<h1><a href='blogpost.php?reviewID=" .$row['reviewID'] . "'>" . $row['title'] . "</a></h1>";
                echo "<p><em>posted on " . date("F jS Y, g:ia",strtotime($row['date'])) . " by " . $row['firstName'] . " in " .$row['genreName'] . " on " . $row['platformName'] . "</em></p>"; //display the date, author and category
            
            /* star rating */
            $rating= $row['rating']; //retrieve rating from database
            
            for($i=0;$i<$rating;$i++)
                {
                    echo "<img src='../images/gold-star.png' class='rating' alt='filled star' />"; //echo filled stars
                }
            for($i=0;$i<5-$rating;$i++)
                {
                    echo "<img src='../images/Five-pointed_star.png' class='rating' alt='unfilled star' />";//echo unfilled stars
                }
                
                echo "<p>" . (substr(($row['content']),0,300)) . "..." . "<a href='blogpost.php?reviewID=" . $row['reviewID'] . "'>" . "Read More" . "</a><br />"; 
                //limit the display to 300 characters and add a 'read more' link
                echo "<p><a href='blogpost.php?reviewID=" . $row['reviewID'] . "'>" . "Comments(" . $row['commentcount'] . ")</a></p>"; //add the number of comments on the post
            }
    ?>
    <?php
        include '../includes/sidebar.php';
    ?>
    </div>
</section> <!-- end content -->

        </div>
</div>
    <?php
    include '../includes/footer.php';
?>