<?php
    include "../includes/connect.php";
    
    //display HTML tag for each genre
    $sql = "SELECT *
            FROM platform
            WHERE platform.platformID=" . $_GET['platformID'];
            //retrieve the genre
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    while ($row = mysqli_fetch_array($result))
        {
            $page = $row['platformName'];
        }
    include "../includes/header.php";
    include "../includes/navigation.php";
?>
<div id="main">

        <section>
            <div class="container">
    <?php
        $sql = "SELECT *
            FROM platform
            WHERE platform.platformID=" . $_GET['platformID']; //retrieve the genre
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
        
        $row = mysqli_fetch_array($result);
        echo "<h1>" . $row['platformName'] . "</h1>"; //display the category

        $sql = "SELECT review.*, genre.*, admin.adminID, admin.firstName, platformName,
                COUNT(comment.reviewID) AS commentcount
                FROM review
                INNER JOIN admin ON review.adminID = admin.adminID
                INNER JOIN platform ON review.platformID = platform.platformID
                INNER JOIN genre ON review.genreID = genre.genreID
                LEFT JOIN comment ON review.reviewID = comment.reviewID
                WHERE platform.platformID='" . $_GET['platformID'] .
                "'GROUP BY review.reviewID, comment.reviewID
                ORDER BY review.date DESC"; //retrieve records that match the genre and count the number of comment
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

        while ($row = mysqli_fetch_array($result))
            {
                if((is_null($row['image'])) || (empty($row['image']))) //if the photo field is NULL or empty
                    {
                        echo "<img src='../images/default.png' width=620 height=300 alt='GameOn Banner' /></p>"; //display the default photo
                    }
                else
                    {
                        echo "<img src='../images/" . ($row['image']) . "'" . 'width=620 height=300 alt="GameOn"' . "/>"; //display the review image
                    }
                echo "<h1><a href='blogpost.php?reviewID=" .$row['reviewID'] . "'>" . $row['title'] . "</a></h1>";
                echo "<p><em>posted on " . date("F jS Y, g:ia",strtotime($row['date'])) . " by " . $row['firstName'] . " in " . $row['genreName'] . " on " . $row['platformName'] . "</em></p>"; //display the date, author, genre and platform
            
                /* star rating */
                $rating = $row['rating']; //retrieve rating from database
                for($i=0;$i<$rating;$i++)
                    {
                        echo "<img src='../images/gold-star.png' class='rating' alt='filled star' />"; //echo filled stars
                    }
                for($i=0;$i<5-$rating;$i++)
                    {
                        echo "<img src='../images/Five-pointed_star.png' class='rating' alt='unfilled star' />"; //echo unfilled stars
                    }
                echo "<p>" . (substr(($row['content']),0,300)) . "..." . "<a href='blogpost.php?reviewID=" . $row['reviewID'] . "'>" . "Read More" . "</a><br />"; //create a read more link
                echo "<p><a href='blogpost.php?reviewID=" . $row['reviewID'] . "'>" . "Comments (" .$row['commentcount'] . ")</a></p>"; //add the number of comment on the post
            }
    ?>
    <?php
        include '../includes/sidebar.php';
    ?>
</div>
</section> <!-- end content -->

        </div>
</div>

<?php
    include '../includes/footer.php';
?>