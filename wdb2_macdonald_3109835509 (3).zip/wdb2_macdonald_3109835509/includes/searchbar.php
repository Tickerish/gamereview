  <div id="navigation-bar" class="clearfix">
            
            <form id="search" action="../pages/search.php" method="get">
                <div id="label"><label for="search-terms" id="search-label">search</label></div>
                <div id="input"><input type="text" name="search-terms" id="search-terms" placeholder="Enter search terms..."></div>
            </form>
        </div>