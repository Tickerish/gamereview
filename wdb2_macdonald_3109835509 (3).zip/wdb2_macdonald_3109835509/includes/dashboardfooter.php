<footer>
<div id="info-bar">
    <div class="container clearfix">
        <span class="all-tutorials"><a href="#">&copy; 2014 | Emma Macdonald</a></span>
        <span class="back-to-tutorial"><a href="../pages/index.php">Main Site &#8594;</a></span>
    </div>
</div><!-- /#top-bar -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="../js/classie.js"></script>
    <script src="../js/search.js"></script>
</footer><!-- /footer -->
</body>