<?php
    include "connect.php";
?>
<div class="col-md-4">
<h2>Genre</h2>

    <?php
        //display the genres
        $sql = "SELECT genre.*, COUNT(review.genreID) AS catnum 
                FROM genre
                INNER JOIN review ON genre.genreID = review.genreID
                GROUP BY genre.genreID
                ORDER BY genreName ASC"; //count the number of posts in each genre_platform
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
        while($row = mysqli_fetch_array($result))
            {
               echo "<p><a href='bloggenres.php?genreID=" . $row['genreID'] . "'>". $row['genreName'].  " (" . $row['catnum'] . ")</a></p>";
            }
    ?>
</div>
<div class="col-md-4">
<h2>Platform</h2>

    <?php
        //display the genres
        $sql = "SELECT platform.*, COUNT(review.platformID) AS catnum 
                FROM platform
                INNER JOIN review ON platform.platformID = review.platformID
                GROUP BY platform.platformID
                ORDER BY platformName ASC"; //count the number of posts in each genre_platform
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
        while($row = mysqli_fetch_array($result))
            {
               echo "<p><a href='blogplatforms.php?platformID=" . $row['platformID'] . "'>" . $row['platformName'] .  " (" . $row['catnum'] . ")</a></p>";
            }
    ?>
    </div>
   <div class="col-md-4">
        <h2>Archives</h2>

     <?php
        //display the genres
        $sql = "SELECT month(date), monthname(date), year(date), COUNT(*) AS monthnum
                FROM review
                GROUP BY monthname(date)
                ORDER BY month(date)"; //select month and year from datetime field plus groups by month
        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
        while($row = mysqli_fetch_array($result))
            {
               echo "<p><a href='blogarchives.php?month=" . $row['month(date)'] . "'>". $row['monthname(date)']. " " . $row['year(date)'] .  " (" . $row['monthnum'] . ")</a></p>";
            }
    ?>
    </div>
    </div>
</div>