<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0" />
        <meta name="description" content="" />
        <title><?php echo $page ?></title>
        
        <!-- link to favicon -->
        <link href="../images/favicon.ico" rel="shortcut icon">
        <!-- link to Bootstrap core CSS -->
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        
        <!-- link to external CSS -->
        <?php
            $sql = "SELECT stylesheet, current.themeID
                    FROM theme
                    INNER JOIN current USING(themeID)"; //select the stylesheet from the theme table and the themeID from the current table
            $result = mysqli_query($con, $sql) or die(mysqli_error($con));//run the query
            
            $row = mysqli_fetch_array($result); //store the results in a variable named $row
        ?>
        
        <link rel="stylesheet" href="../css/<?php echo $row['stylesheet']?>">
        
        <!-- enable html5 in IE 8 and below -->
        <!--[if IE]>
            <script src="http://html5shiv.googlecode.com/svn/trunk/html5.s"></script>
        <![endif]-->
                
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
        
        <?php
            session_start();
        ?>
    </head>
<body>