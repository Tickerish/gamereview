<body>
    <div id="wrapper">
<header>
    <div class="container clearfix">
<h1 id="logo">GameOn</h1>
        
        <?php
    if((isset($_SESSION['member'])) || (isset($_SESSION['admin']))) //check to see if a member or an admin is logged in and, if so, display the logged in menu items
    {
?>
        <nav class="registration">
    <ul>
        <a href="../pages/account.php">My Account</a>&nbsp; | &nbsp;
        <a href="../pages/logout.php">Logout</a>
    </ul>
</nav> <!-- end registration -->

<?php
    }
    else
    {
?>

<nav class="registration">
    <ul>
        <a href="../pages/login.php">Login</a>
        <a href="../pages/registration.php">Sign Up</a>
    </ul>
</nav> <!--end registration -->

<?php
    }
?>
<nav class="main">
    <ul>
        <a <?php if($page=='Home'){echo "class='current'";} ?> href="../pages/index.php">Home</a>
        <a <?php if($page=='About'){echo "class='current'";} ?> href="#">About</a>
        <a <?php if($page=='Say Hello'){echo "class='current'";} ?> href="#">Say Hello</a>
        <a <?php if($page=='Community'){echo "class='current'";} ?> href="../pages/community.php">Community</a>
    </ul>
</nav> <!--end main -->

        </header>