<body>
    <div id="wrapper">
        <header>
            <h1 id="logo">Dashboard</h1>
<nav class="registration">
    <ul>
        <a href="../pages/logout.php">Logout</a>
       <a href="../pages/index.php">View Site</a> 
    </ul>
</nav> 

<nav class="main">
    <ul>
        <a <?php if($page=='Home'){echo "class='current'";} ?> href="../admin/index.php">Dashboard</a>
        <a <?php if($page=='Reviews'){echo "class='current'";} ?> href="../admin/reviews.php">Reviews</a>
        <a <?php if($page=='Genres'){echo "class='current'";} ?> href="../admin/genres.php">Genres</a>
        <a <?php if($page=='Platforms'){echo "class='current'";} ?> href="../admin/platforms.php">Platforms</a>
        <a <?php if($page=='Administrators'){echo "class='current'";} ?> href="administrators.php">Administrators</a> 
        <a <?php if($page=='My Account'){echo "class='current'";} ?> href="account.php">My Account</a>
        <a <?php if($page=='Themes'){echo "class='current'";} ?> href="themes.php">Themes</a>
 </ul>
</nav>
            </header>