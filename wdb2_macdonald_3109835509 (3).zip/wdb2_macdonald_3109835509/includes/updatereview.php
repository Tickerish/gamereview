<?php
    $reviewID = $_GET['reviewID']; //retrieve reviewID from URL
 
    $sql = "SELECT review.*, genre.*, platform.*, admin.firstName, admin.lastName '
            FROM review 
            JOIN admin USING (adminID) 
            JOIN genre USING (genreID)
            JOIN platform USING (platformID) 
            WHERE reviewID = '$reviewID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
    $row = mysqli_fetch_array($result);
 ?>