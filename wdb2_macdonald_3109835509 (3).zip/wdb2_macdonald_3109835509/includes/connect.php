<?php
    $con = mysqli_connect("localhost","root","","wdb2_macdonald_3109835509");
        //check connection and, if broken, display an error message
        if(mysqli_connect_error($con))
        {
            echo "Unable to connect to the server: " . mysqli_connect_error();
            exit();
        }
?>