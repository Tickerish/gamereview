<?php
    session_start();
    include "../includes/connect.php";
?>

<?php
    $platform = mysqli_real_escape_string($con, $_POST['platformName']); //prevent SQL injection
    $description = mysqli_real_escape_string($con, $_POST['platformDescription']);

    $sql = "INSERT INTO platform (platformName, platformDescription)
            VALUES ('$platform', '$description')";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
    
    $_SESSION['success'] = 'New platform successfully added.'; //if new genre is added successfully intialise a session called 'success' with msg
    header("location:platforms.php"); //redirect to genres.php
?>