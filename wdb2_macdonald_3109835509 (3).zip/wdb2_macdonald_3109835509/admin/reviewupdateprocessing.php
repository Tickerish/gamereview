<?php
    session_start();
    include "../includes/connect.php";
?>

<?php
    $reviewID = $_POST['reviewID']; //retrieve reviewID from hidden form field
 
    $title = mysqli_real_escape_string($con, $_POST['title']); //prevent SQL injection
    $content = mysqli_real_escape_string($con, $_POST['content']);
    $adminID = mysqli_real_escape_string($con, $_POST['adminID']);
    $genreID = mysqli_real_escape_string($con, $_POST['genreID']);
    $platformID = mysqli_real_escape_string($con, $_POST['platformID']);
    $rating = mysqli_real_escape_string($con, $_POST['rating']);
 
    $sql="  UPDATE review 
            SET title='$title', content='$content', date=NOW(), adminID='$adminID', genreID='$genreID' , platformID='$platformID', rating='$rating' 
            WHERE reviewID='$reviewID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
 
    $_SESSION['success'] = 'Review updated successfully'; //if update is successful initialise a session called 'success' with a msg
    header("location:reviewupdate.php?reviewID=" . $reviewID); //redirect to reviewupdate.php
?>