<?php
    $page = "Update Genre";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<?php

    $genreID = $_GET['genreID']; //retrieve reviewID from URL
    $sql = "SELECT *
            FROM genre
            WHERE genreID = '$genreID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
    $row = mysqli_fetch_array($result);
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
                  <?php
                        //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>';
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                        elseif(isset($_SESSION['success'])) //if session success is set
                            {  
                                echo '<div class="success"';
                                echo '<p>' . $_SESSION['success'] . '</p>';
                                echo '</div>';
                                unset($_SESSION['success']); //unset session success
                            }
                    ?>
                    
                    <h1>Update Genre</h1>
                    
                        <form action="genreupdateprocessing.php" method="post">
                            <label>Genre*</label>
                                <p><input type="text" name="genreName" required value="<?php echo $row['genreName'] ?>" /></p>
                            <br />
                            
                            <label>Description*</label>
                                <p><textarea name="genreDescription" rows="10" cols="60%" required><?php echo $row['genreDescription']?></textarea></p>
                            <br />
                            
                            <input type="hidden" name="genreID" value="<?php echo $genreID; ?>">
                            <p><a href="#"><input type="submit" name="genreupdate" class="btn" value="Update Genre"/></a></p>
                        </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>