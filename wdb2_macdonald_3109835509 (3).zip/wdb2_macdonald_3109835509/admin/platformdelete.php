<?php
    session_start();
    include '../includes/connect.php';
?>

<?php
    $platformID = $_GET['platformID'];
    
    $sql = "DELETE platform.*
            FROM platform
            WHERE platformID = '$platformID'"; //delete the genre from the genre table
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    //user messages
    $_SESSION['success'] = 'Platform delete successfully.'; //register a session with a success message
    header('location:platforms.php');
?>