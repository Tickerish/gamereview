<?php
    $page = "Dashboard - Add New Review";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php'; //includes a session_start()
    include '../includes/dashboardnav.php';
    include "../includes/logincheckadmin.php";
?>


<div id="main">

        <section>
            <div class="container">
                <div class="dashboard">
 <h1>Add New Review</h1>
                         <div class="reviewNew">
 
    <?php
        //user messages
        if(isset($_SESSION['error'])) //if session error is set
            {
                echo '<div class="error">';
                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                echo '</div>';
                unset($_SESSION['error']); //unset session error
            }
        elseif(isset($_SESSION['success'])) //if session success is set
            {
                echo '<div class="success">';
                echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                echo '</div>';
                unset($_SESSION['success']); //unset session success
            }
 ?>
 
 <form action="reviewnewprocessing.php" method="post" enctype="multipart/form-data">
     <p class="row"><label>*Review title: </label></p>
        <input type="text" name="title" required />
     <br />
 
    <p class="row"><label>*Review Content: </label></p>
       <textarea rows="10" cols="60%" name="content" ></textarea>
     <br />
 
    <p class="row"><label>Author*</label></p>
    <!-- create a drop-down list populated by the admin details stored in the database --> 
        <select name='adminID'>
            <option value="">Please select</option>
 
            <?php
            $sql="SELECT * FROM admin";
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            while ($row = mysqli_fetch_array($result))
                {
                    echo "<option value=" . $row['adminID'] . ">" . $row['firstName'] . " " . $row['lastName'] . "</option>";
                }
            ?>
 
        </select>
         
     <br />
 
    <p class="row"><label>Genre*</label></p>
 
 <!-- create a drop-down list populated by the categories stored in the database -->
 <select name='genreID'>
    <option value="">Please select</option>
 
        <?php
            $sql="SELECT * FROM genre"; 
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                while ($row = mysqli_fetch_array($result))
                    {
                        echo "<option value=" . $row['genreID'] . ">" . $row['genreName'] . "</option>";
                    }
        ?>
     </select><br />
 
    <p class="row"> <label>Platform*</label></p>
 
 <!-- create a drop-down list populated by the categories stored in the database -->
 <select name='platformID'>
    <option value="">Please select</option>
 
        <?php
            $sql="SELECT * FROM platform"; 
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                while ($row = mysqli_fetch_array($result))
                    {
                        echo "<option value=" . $row['platformID'] . ">" . $row['platformName'] . "</option>";
                    }
        ?>
     </select>
     <br />
 
   <p class="row"><label>Rating*</label></p>
 
    <!-- create a drop-down list populated by the rating stored in the database -->
        <select name='rating'>
            <option value="">Please select</option>
 
            <!-- use a for loop to create the rating options up to a maximum of 5 --> 
            <?php for ($i = 1; $i <= 5; $i++) : ?>
                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
            <?php endfor; ?>
 
        </select><br />
 
    <p class="row"><label>Image</label></p>
        <input type="file" name="image" />
    <br /> 
    <p>Accepted files are JPG, GIF or PNG. Maximum size is 500kb.</p> 
    <p class="row"><input type="hidden" name="reviewID" value="<?php echo $reviewID; ?>">
     <p><a href="#"><input type="submit" name="reviewnew" class='btn' value="Add New Review" /></a></p> 
 </form>
                             </div>
         </div>
 </div>
</section> <!-- end content -->

        </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>
