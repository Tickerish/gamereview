<?php
    $page = "Themes";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>
<div id="main">
        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
            
                        //user message
                        if(isset($_SESSION['error'])) //if session error is set
                        {
                            echo '<div class="error">';
                            echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                            echo '</div>';
                            unset($_SESSION['error']); //unset session error
                        }
                        elseif(isset($_SESSION['success'])) //if session success is set
                        {
                            echo '<div class="success"';
                            echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                            echo '</div>';
                            unset($_SESSION['success']); //unset session success
                        }
                    ?>
                    <h1>Themes</h1>
                        <p>Select a theme for the website.</p>
                            <?php
                                $sql = "SELECT * FROM theme"; //select the data from the theme table
                                $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

                                while($row = mysqli_fetch_array($result))
                                    {
                                        echo "<img src='../images/" . ($row['image']) . "'" . 'width=500 height=300 alt="Assassins creed"' . "/>"; //display the theme photo
                                        echo "<h2>" . $row['name'] . "</h2>"; //display the theme name
                                        echo "<p>" . $row['description'] . "</p>"; //display the theme description
                                        echo "<form action='themeprocessing.php' method='post'>";
                                        echo "<input type='hidden' name='themeID' value=" . $row['themeID'] .">"; //A hidden form field holds the themeID
                                        echo "<p><a href='#'><input type='submit' class='btn' value='Activate'></a>";
                                        echo "</form>"; 
                                        echo "<br />";
                                    }
                            ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>