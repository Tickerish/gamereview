<?php
    session_start();
    include "../includes/connect.php";
?>

<?php
    $genre = mysqli_real_escape_string($con, $_POST['genreName']); //prevent SQL injection
    $description = mysqli_real_escape_string($con, $_POST['genreDescription']);

    $sql = "INSERT INTO genre (genreName, genreDescription)
            VALUES ('$genre', '$description')";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
    
    $_SESSION['success'] = 'New genre successfully added.'; //if new genre is added successfully intialise a session called 'success' with msg
    header("location:genres.php"); //redirect to genres.php
?>