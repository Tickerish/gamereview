<?php
    $page = "Dashboard - Genres";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<div id="main">
   <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
                        //user message
                        if(isset($_SESSION['error'])) //if session error is set
                        {
                            echo '<div class="error">';
                            echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                            echo '</div>';
                            unset($_SESSION['error']); //unset session error
                        }
                        elseif(isset($_SESSION['success'])) //if session success is set
                        {
                            echo '<div class="success"';
                            echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                            echo '</div>';
                            unset($_SESSION['success']); //unset session success
                        }
                    ?>
                    
                    <h1>Genres</h1>
                    
                    <p><a href="genrenew.php"><input type="button" class="btn" value="Add New"></a></p>
                    
                    <?php
                        //retrieve the total number of genres
                        $sql = "SELECT * FROM genre";
                        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                        $numrow = mysqli_num_rows($result); //retrieve the number of rows
                        echo "<p>There are currently <strong>" . $numrow . "</strong> Genres.</p>"; //echo the total number of genres
                        include "../includes/paginationcreate.php"; //include code to build pagination
                        
                        //retrieve data from database for display
                        $sql = "SELECT genre.*, COUNT(review.genreID) AS genreCount 
                                FROM genre 
                                LEFT JOIN review ON genre.genreID = review.genreID
                                GROUP BY genre.genreID
                                ORDER BY genreName ASC 
                                LIMIT $offset, $rowsperpage"; //count the number of posts in each genre
                        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

                        echo "<table class='assassinTable'>"; //display records in table format
                        echo "<tr class='accomplice'>";
                        echo "<td>Genre</td><td>Description</td><td>Reviews</td>";
                        echo "</tr>";
                        
                            while($row = mysqli_fetch_array($result))
                                {
                                    echo "<tr>";
                                    echo "<td class='target'>" . $row['genreName'] . "</td>";
                                    echo "<td class='target'>" . $row['genreDescription'] . "</td>";
                                    echo "<td class='target'>" . $row['genreCount'] . "</td>";
                                    echo "<td class='target'><a href=\"genreupdate.php?genreID={$row['genreID']}\">Update</a> | 
                                              <a href=\"genredelete.php?genreID={$row['genreID']}\" onclick=\"return confirm('Are you sure you want to delete this genre?')\">Delete</a></td>";
                                    echo "</tr>";
                                }
                        echo "</table>";
                        include '../includes/paginationdisplay.php'; //include code to display pagination 
                    ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php
    include '../includes/dashboardfooter.php';
?>