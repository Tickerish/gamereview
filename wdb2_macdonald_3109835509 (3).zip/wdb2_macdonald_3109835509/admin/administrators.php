<?php
    $page= "Administrators";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
                        //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                        elseif(isset($_SESSION['success'])) //if session success is set
                            {
                                echo '<div class="success">';
                                echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                                echo '</div>';
                                unset($_SESSION['success']); //unset success message
                            }
                    ?>
                    
                    <h1>Administrator</h1>
                        <p><a href="administratornew.php"><input type="button" class="btn" value="Add New Administrator"></a></p>
                            <?php
                                //retrieve total number of administrators
                                $sql = "SELECT * FROM admin";
                                $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                                $numrow = mysqli_num_rows($result); //retrieve the number of rows
                                echo "<p>There are currently <strong>" . $numrow . "</strong> Administrators.</p>";
                                include '../includes/paginationcreate.php'; //include code to build pagination

                                //retrieve data from database for display
                                $sql = "SELECT admin.*, COUNT(review.adminID) AS reviewCount
                                        FROM admin
                                        LEFT JOIN review USING(adminID)
                                        GROUP BY admin.adminID
                                        ORDER BY username ASC
                                        LIMIT $offset, $rowsperpage";
                                $result = mysqli_query($con, $sql) or die(mysqli_error($con));
                                echo "<table class='assassinTable'>"; //display records in a table format
                                echo "<tr class='accomplice'>";
                                echo "<td>Username</td><td>Name</td><td>Email</td><td>Datetime</td><td>Reviews</td>";
                                echo "</tr>";
                                    while($row = mysqli_fetch_array($result))
                                        {
                                            echo "<tr>";
                                            echo "<td class='target'>" . $row['username'] . "</td>";
                                            echo "<td class='target'>" . $row['firstName'] . " " . $row['lastName'] . "</td>";
                                            echo "<td class='target'><a ref='mailto:" . $row['email'] . "'>" . $row['email'] . "</a></td>";
                                            echo "<td class='target'>" . date("d/m/y H:i",strtotime($row['date'])) . "</td>";
                                            echo "<td class='target'>" . $row['reviewCount'] . "</td>";
                                            echo "</tr>";
                                        }
                                echo "</table>";
                                include "../includes/paginationdisplay.php"; //include code to display pagination
                            ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>