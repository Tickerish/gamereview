<?php
    session_start();
    include'../includes/connect.php';
?>

<?php
    $platformID = $_POST['platformID']; //retrieve reviewID from hidden form field 
    $platformName = mysqli_real_escape_string($con, $_POST['platformName']); //prevent SQL injection
    $platformDescription = mysqli_real_escape_string($con, $_POST['platformDescription']);

    $sql = "UPDATE platform SET platformName='$platformName', platformDescription='$platformDescription'
            WHERE platformID = '$platformID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    $_SESSION['success'] = 'Platform updated successfully.'; //if category update is successful intialise a session called 'success' with msg
    header("location:platformupdate.php?platformID=" . $platformID); //redirect to genreupdate.php
?>