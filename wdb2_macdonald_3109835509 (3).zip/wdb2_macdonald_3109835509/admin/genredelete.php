<?php
    session_start();
    include '../includes/connect.php';
?>

<?php
    $genreID = $_GET['genreID'];
    
    $sql = "DELETE genre.*
            FROM genre
            WHERE genreID = '$genreID'"; //delete the genre from the genre table
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    //user messages
    $_SESSION['success'] = 'Genre delete successfully.'; //register a session with a success message
    header('location:genres.php');
?>