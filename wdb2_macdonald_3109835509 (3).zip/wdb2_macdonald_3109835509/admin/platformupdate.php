<?php
    $page = "Update Platform";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<?php

    $platformID = $_GET['platformID']; //retrieve reviewID from URL
    $sql = "SELECT *
            FROM platform
            WHERE platformID = '$platformID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
    $row = mysqli_fetch_array($result);
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
                  <?php
                        //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>';
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                        elseif(isset($_SESSION['success'])) //if session success is set
                            {  
                                echo '<div class="success"';
                                echo '<p>' . $_SESSION['success'] . '</p>';
                                echo '</div>';
                                unset($_SESSION['success']); //unset session success
                            }
                    ?>
                    
                    <h1>Update Platform</h1>
                    
                        <form action="platformupdateprocessing.php" method="post">
                            <label>Platform*</label>
                                <p><input type="text" name="platformName" required value="<?php echo $row['platformName'] ?>" /></p>
                            <br />
                            
                            <label>Description*</label>
                                <p><textarea name="platformDescription" rows="10" cols="60%" required><?php echo $row['platformDescription']?></textarea></p>
                            <br />
                            
                            <input type="hidden" name="platformID" value="<?php echo $platformID; ?>">
                            <p><a href="#"><input type="submit" name="platformupdate" class="btn" value="Update Platform"/></a></p>
                        </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>