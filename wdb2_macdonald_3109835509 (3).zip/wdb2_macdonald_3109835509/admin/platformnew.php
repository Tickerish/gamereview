<?php
    $page = "Add a New Platform";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php'; //includes a session_start()
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
                        //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                    ?>
                    <h1>Add A New Platform</h1>
                        <form action="platformnewprocessing.php" method="post">
                            <label>Platform*</label>
                                <p><input type="text" name="platformName" required /></p>
                            <br />
                            <label>Description*</label>
                                <p><textarea name="platformDescription" rows="10" cols="60%"></textarea></p>
                            <br />
                            <p><a href="#"><input type="submit" name="platformnew" class="btn" value="Add a New Platform"/></a></p>
                        </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>