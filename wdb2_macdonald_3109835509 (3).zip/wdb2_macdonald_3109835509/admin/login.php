<?php
    $page ="Admin Login";
    include "../includes/connect.php";
    include "../includes/header.php";
    include "../includes/navigation.php";
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="login">
                <div class="form">
    <h1>Administrators Only</h1>
    <p>Welcome back.</p>
    
        <?php
            //user messages
            if(isset($_SESSION['error'])) //if session error is set
                {
                    echo '<div class="error">';
                    echo '<p>' . $_SESSION['error'] . '</p>'; //display error messgae
                    echo '</div>';
                    unset($_SESSION['error']); //unset session error
                }
        ?>
    
    <form action="../pages/loginprocessing.php" method="post">
        <input type="text" name="username" id="username" placeholder="Enter your username" required/> <br />
        <input type="password" name="password" id="password" placeholder="Enter your password" requried/> <br />
        <input type="hidden" value="<?php echo $_GET['reviewID']; ?>" name="reviewID" />
        <p><input type="submit" name="Login" value="Login" class="btn" /></p>
    </form>
                    </div>
                    </div>
                </div>
</section> <!-- end content -->

        </div>
</div>

<?php
    include "../includes/footer.php";
?>