<?php
    $page = "My Account";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>
<?php
    $adminID = $_SESSION['user']; //retrieve the adminID from the current session
    
    $sql = "SELECT * FROM admin WHERE adminID= '$adminID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    $row = mysqli_fetch_array($result);
?>
<div id="main">
    
        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
                    //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                        elseif(isset($_SESSION['success'])) //if session success is set
                            {
                                echo '<div class="success">';
                                echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                                echo '</div>';
                                unset($_SESSION['success']); //unset success message
                            }
                    ?>
                    
                    <h1>My Account</h1>
                        <p>Update your account details.</p>
                            <form action="accountprocessing.php" method="post">
                                <label>Username*</label>
                                    <p><input type="text" name="username" required value="<?php echo $row['username'] ?>" readonly/></p>
                                <br />
                                <label>&nbsp;</label>
                                    <p>Username cannot be updated</p>
                                <label>First Name*</label>
                                    <p><input type="text" name="firstName" required value="<?php echo $row['firstName']?>"/></p>
                                <br />
                                <label>Last Name*</label>
                                    <p><input type="text" name="lastName" required value="<?php echo $row['lastName']?>"/></p>
                                <br />
                                <label>Email*</label>
                                    <p><input type="email" name="email" required value="<?php echo $row['email']?>"/></p>
                                <br />
                                <input type="hidden" name="adminID" value="<?php echo $adminID; ?>">
                                <p><a href="#"><input type="submit" class="btn" a href="#" name="accountupdate" value="Update Account" /></a></p>
                            </form>
                    <h1>Update Password</h1>
                        <p>Passwords must have a minimum of 8 characters.</p>
                    
                            <form action="accountpasswordprocessing.php" method="post">
                                <label>New Password*</label>
                                    <p><input type="password" name="password" pattern=".{8,}" title="Password must be 8 characters or more" required /></p>
                                <br />
                                <input type="hidden" name="adminID" value="<?php echo $adminID; ?>"/>
                                <p><a href="#"><input type="submit" name="passwordupdate" class="btn" value="Update Password"/></a></p>
                            </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>