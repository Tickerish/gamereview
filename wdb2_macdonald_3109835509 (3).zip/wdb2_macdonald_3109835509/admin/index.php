<?php
    $page = "Dashboard - Home";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include "../includes/logincheckadmin.php";
?>
<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
            
 
 
    <p class="welcomemsg">Welcome to your custom Content Management System.</p>
 
 <?php
    $sql = "SELECT (SELECT COUNT(*) 
            FROM review) 
            AS 'totalReviews', 
            (SELECT COUNT(*) 
            FROM genre) 
            AS 'totalgenres',
            (SELECT COUNT(*) 
            FROM platform) 
            AS 'totalplatforms', 
            (SELECT COUNT(*) 
            FROM admin) 
            AS totalAdministrators, 
            (SELECT COUNT(*) 
            FROM theme) 
            AS totalThemes";
 $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
 
 while ($row = mysqli_fetch_array($result))
    {
        echo "<table class='assassinTable'>";
            echo "<th colspan='2' class='accomplice'>At a glance</th>";
            echo "<tr>";
                echo "<td class='betaTable'>" . $row['totalReviews'] . "</td><td class='omegaTable'> Total Reviews</td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td class='betaTable'>" . $row['totalgenres'] . "</td><td class='omegaTable'> Total Genres</td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td class='betaTable'>" . $row['totalplatforms'] . "</td><td class='omegaTable'> Total Platforms</td>";
            echo "</tr>";
            echo "<tr >";
                echo "<td class='betaTable'>" . $row['totalAdministrators'] . "</td><td class='omegaTable'> Total Administrators</td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td class='betaTable'>" . $row['totalThemes'] . "</td><td class='omegaTable'> Total Themes</td>";
            echo "</tr>";
        echo "</table>";
    }
 ?>
                    </div>
 </div>
</section> <!-- end content -->

        </div>
</div>
 
<?php
    include '../includes/dashboardfooter.php';
?>