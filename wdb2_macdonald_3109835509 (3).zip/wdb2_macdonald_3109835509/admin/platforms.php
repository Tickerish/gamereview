<?php
    $page = "Dashboard - Platforms";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php';
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<div id="main">
    <div id="content">
        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
                        //user message
                        if(isset($_SESSION['error'])) //if session error is set
                        {
                            echo '<div class="error">';
                            echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                            echo '</div>';
                            unset($_SESSION['error']); //unset session error
                        }
                        elseif(isset($_SESSION['success'])) //if session success is set
                        {
                            echo '<div class="success"';
                            echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
                            echo '</div>';
                            unset($_SESSION['success']); //unset session success
                        }
                    ?>
                    
                    <h1>Platforms</h1>
                    
                    <p><a href="platformnew.php"><input type="button" class="btn" value="Add New"></a></p>
                    
                    <?php
                        //retrieve the total number of genres
                        $sql = "SELECT * FROM platform";
                        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                        $numrow = mysqli_num_rows($result); //retrieve the number of rows
                        echo "<p>There are currently <strong>" . $numrow . "</strong> Platforms.</p>"; //echo the total number of genres
                        include "../includes/paginationcreate.php"; //include code to build pagination
                        
                        //retrieve data from database for display
                        $sql = "SELECT platform.*, COUNT(review.platformID) AS platformCount 
                                FROM platform 
                                LEFT JOIN review ON platform.platformID = review.platformID
                                GROUP BY platform.platformID
                                ORDER BY platformName ASC 
                                LIMIT $offset, $rowsperpage"; //count the number of posts in each genre
                        $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
                        
                        echo "<table class='assassinTable'>"; //display records in table format
                        echo "<tr class='accomplice'>";
                        echo "<td>platform</td><td>Description</td><td>Reviews</td>";
                        echo "</tr>";
                            while($row = mysqli_fetch_array($result))
                                {
                                    echo "<tr>";
                                    echo "<td class='target'>" . $row['platformName'] . "</td>";
                                    echo "<td class='target'>" . $row['platformDescription'] . "</td>";
                                    echo "<td class='target'>" . $row['platformCount'] . "</td>";
                                    echo "<td class='target'><a href=\"platformupdate.php?platformID={$row['platformID']}\">Update</a> | 
                                              <a href=\"platformdelete.php?platformID={$row['platformID']}\" onclick=\"return confirm('Are you sure you want to delete this genre?')\">Delete</a></td>";
                                    echo "</tr>";
                                }
                        echo "</table>";
                        include '../includes/paginationdisplay.php'; //include code to display pagination 
                    ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php
    include '../includes/dashboardfooter.php';
?>