<?php
    $page = "Add a New Genre";
    include '../includes/connect.php';
    include '../includes/dashboardheader.php'; //includes a session_start()
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<div id="main">

        <section>
            <div class="container">
                <div class="dashboard">
                    <?php
                        //user messages
                        if(isset($_SESSION['error'])) //if session error is set
                            {
                                echo '<div class="error"';
                                echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
                                echo '</div>';
                                unset($_SESSION['error']); //unset session error
                            }
                    ?>
                    <h1>Add A New Genre</h1>
                        <form action="genrenewprocessing.php" method="post">
                            <label>Genre*</label>
                                <p><input type="text" name="genreName" required /></p>
                            <br />
                            <label>Description*</label>
                                <p><textarea name="genreDescription" rows="10" cols="60%"></textarea></p>
                            <br />
                            <p><a href="#"><input type="submit" name="genrenew" class="btn" value="Add a New Genre"/></a></p>
                        </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
    include '../includes/dashboardfooter.php';
?>