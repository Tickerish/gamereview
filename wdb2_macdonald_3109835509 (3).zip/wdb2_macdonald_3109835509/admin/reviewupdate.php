<?php
    $page = "Dashboard - Update Review";

    include '../includes/connect.php';
    include '../includes/dashboardheader.php'; //includes a session_start()
    include '../includes/dashboardnav.php';
    include '../includes/logincheckadmin.php';
?>

<?php
    $reviewID = $_GET['reviewID']; //retrive reviewID from URL
    $sql = "SELECT review.*, genre.*, platform.*, admin.firstName, admin.lastName 
            FROM review
            JOIN admin USING (adminID)
            JOIN genre USING (genreID)
            JOIN platform USING (platformID)
            WHERE reviewID = '$reviewID'";
    $result = mysqli_query($con, $sql) or die (mysqli_error($con)); //run the query
    $row = mysqli_fetch_array($result);
?>
<div id="main">
    
        <section>
            <div class="container">
                <div class="dashboard">
    <h1>Update Review</h1>
 
 <?php
    //user messages
    if(isset($_SESSION['error'])) //if session error is set
        {
            echo '<div class="error">';
            echo '<p>' . $_SESSION['error'] . '</p>'; //display error message
            echo '</div>';
            unset($_SESSION['error']); //unset session error
        }
    elseif(isset($_SESSION['success'])) //if session success is set
        {
            echo '<div class="success">';
            echo '<p>' . $_SESSION['success'] . '</p>'; //display success message
            echo '</div>';
            unset($_SESSION['success']); //unset session success
        }
 ?>
    
    <form action="reviewupdateprocessing.php" method="post">
        <label>Title*</label> 
            <p><input type="text" name="title" required value="<?php echo $row['title'] ?>" /></p>
        <br />
 
        <label>Content*</label>
            <p><textarea rows="10" cols="60%" name="content" required > <?php echo $row['content'] ?></textarea></p>
        <br />
 
        <label>Author*</label>
        <!-- create a drop-down list populated by the admin details stored in the database --> 
             <p><select name='adminID'>
               <option value="<?php echo $row['adminID'] ?>"><?php echo $row['firstName'] . " " . $row['lastName'] ?></option> <!-- display the selected author name -->
 
        <?php
            $sql="SELECT * FROM admin";
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            while ($row = mysqli_fetch_array($result))
                {
                    echo "<option value=" . $row['adminID'] . ">" . $row['firstName'] . " " . $row['lastName'] . "</option>";
                }
        ?>
 
            </select></p><br />
 
        <?php
            $sql = "SELECT genre.* 
                    FROM review 
                    JOIN genre USING (genreID) 
                    WHERE reviewID = '$reviewID'"; //retrieve the selected value
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            $row = mysqli_fetch_array($result);
        ?>
 
        <label>Genre*</label>
        <!-- create a drop-down list populated by the categories stored in the database -->
        <p><select name='genreID'>
        <option value="<?php echo $row['genreID'] ?>">
                       <?php echo $row['genreName'] ?></option> <!-- display the selected category name -->
 
        <?php
            $sql="SELECT * FROM genre"; 
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            while ($row = mysqli_fetch_array($result))
                {
                    echo "<option value=" . $row['genreID'] . ">" . $row['genreName'] ."</option>";
                }
            ?>
 
        </select></p>
        <br />
        
         <?php
            $sql = "SELECT platform.* 
                    FROM review 
                    JOIN platform USING (platformID) 
                    WHERE reviewID = '$reviewID'"; //retrieve the selected value
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            $row = mysqli_fetch_array($result);
        ?>
 
        
        <label>Platform*</label>
        <!-- create a drop-down list populated by the categories stored in the database -->
        <p><select name='platformID'>
        <option value="<?php echo $row['platformID'] ?>">
                       <?php echo $row['platformName'] ?></option> <!-- display the selected category name -->
 
        <?php
            $sql="SELECT * FROM platform"; 
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            while ($row = mysqli_fetch_array($result))
                {
                    echo "<option value=" . $row['platformID'] . ">" . $row['platformName'] ."</option>";
                }
            ?>
 
        </select></p>
        <br />
        <?php
            $sql = "SELECT review.* FROM review WHERE reviewID = '$reviewID'"; //retrieve the selected value
            $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query
            $row = mysqli_fetch_array($result);
        ?>
        <label>Rating*</label>
            <!-- create a drop-down list populated by the rating stored in the database -->
            <p><select name='rating'>
                <option value="<?php echo $row['rating'] ?>"><?php echo $row['rating']?>
                </option> <!-- display the selected rating -->
 
                <!-- use a for loop to create the rating options up to a maximum of 5 --> 
 <?php for ($i = 1; $i <= 5; $i++): ?>
                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
<?php
            endfor; 
?>
 
            </select></p><br />
                <input type="hidden" name="reviewID" value="<?php echo $reviewID; ?>">
        <p><a href="#"><input type="submit" name="reviewupdate" class="btn" value="Update Review" /></a></p><br />
            </form>
 
        <h2>Update Image</h2>
    <?php
        if((is_null($row['image'])) || (empty($row['image']))) //if the photo field is NULL or empty
            {
                echo "<p><img src='../images/default.png' class='banner' alt='default photo' /></p>"; //display the default photo
            }
        else
            {
                echo "<p><img src='../images/" . ($row['image']) . "'" . ' class="banner" alt="review photo"' . "/></p>"; //display the review photo
            }
 ?>
 
 <form action="reviewupdateimageprocessing.php" method="post"enctype="multipart/form-data">
    <input type="hidden" name="reviewID" value="<?php echo $reviewID; ?>">
        <label>New Image</label> 
            <input type="file" name="image" />
        <br /> 
        <p>Accepted files are JPG, GIF or PNG. Maximum size is 500kb.</p> 
     <p><a href="#"><input type="submit" name="imageupdate" class="btn" value="Update Image" /></a></p>
 </form>
</section> 
                </div>
            </section>
    </div>
</div>
<!-- end content -->
 
<?php
 include '../includes/dashboardfooter.php';
?>
     
        