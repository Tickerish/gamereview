<?php
    session_start();
    include'../includes/connect.php';
?>

<?php
    $genreID = $_POST['genreID']; //retrieve reviewID from hidden form field 
    $genreName = mysqli_real_escape_string($con, $_POST['genreName']); //prevent SQL injection
    $genreDescription = mysqli_real_escape_string($con, $_POST['genreDescription']);

    $sql = "UPDATE genre SET genreName='$genreName', genreDescription='$genreDescription'
            WHERE genreID = '$genreID'";
    $result = mysqli_query($con, $sql) or die(mysqli_error($con)); //run the query

    $_SESSION['success'] = 'Genre updated successfully.'; //if category update is successful intialise a session called 'success' with msg
    header("location:genreupdate.php?genreID=" . $genreID); //redirect to genreupdate.php
?>